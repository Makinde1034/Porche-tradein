# Changelog

## v3.2.0

Date: 2022-04-13 \
Tag: [`v3.2.0`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v3.2.0)

### Fixes

* Optimize `MatrixInterface` for Event Matrix JSON ([`ed7348c`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/ed7348c89d723f1c893af2a37342881a1dfb2457))

### DataLayer Updates

* [`CANVAS-577`](https://skyway.porsche.com/jira/browse/CANVAS-577) Remove _Event Matrix_ from bundles ([`!105`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/105))

## v3.1.1

Date: 2022-03-28 \
Tag: [`v3.1.1`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v3.1.1)

### Features

* Remove alias settings for `import` statements ([`!104`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/104))

* Introduce own `noop` helper function ([`6888f1f`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/6888f1f794a12a46aecf2471f3639f3cc12d1d6d))
* Clean and stable dependencies ([`39e1a88`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/39e1a88968452ba84a45e47a8e6f8dc1ca3a3240))

### Fixes

* `useBuiltIns` for modern browsers should be `false` ([`c89114b`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/c89114b076869695f8ab2589cc74504d8886e7ad))

## v3.1.0

Date: 2022-03-10 \
Tag: [`v3.1.0`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v3.1.0)

### Features

* [`CANVAS-541`](https://skyway.porsche.com/jira/browse/CANVAS-541) Include the decoupled validation excel converter ([`!103`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/103))

* Update outdated packages ([`ab646af`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/ab646af2112bebada7673e7f29b41613d601fe2a))

### Fixes

* Fix `webpack` build error releated to `target: 'es5'` ([`11a9d6f`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/11a9d6f18c6bf3538be32d273dcfaf0711cc7001))

### Tests

* Renaming `test` files for better output ([`8d7fd50`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/8d7fd50d010fca58340f31aab0366607fabd0225))

### Documentation

* Using the included _EventMatrix_ build process is now marked as `deprecated` ([`7e8489c`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/7e8489c8f958beb24ea0edc14248722e101d4c61))

## v3.0.4

Date: 2021-11-23 \
Tag: [`v3.0.4`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v3.0.4)

### Documentation

* Fixed missing 'Features' headline in automatic `CHANGELOG.md` ([`26c7277`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/26c7277a59db73e92ba2844e3e5280b65dff979d))

## v3.0.3

Date: 2021-11-23 \
Tag: [`v3.0.3`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v3.0.3)

### Features

* Log `eventName` on failed validation ([`93d6770`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/93d67701691f010427e63f4bdb03005c10569708))

### Documentation

* [`CANVAS-51`](https://skyway.porsche.com/jira/browse/CANVAS-51) User Friendly Documentation ([`!100`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/100))
* Use relative links in all `README.md` files ([`a8be241`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/a8be241c9f322b6bd35d866a7c821605e50c94b1))
* Add information about `.env` and `.npmrc` files ([`e046330`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/e046330a4706d94ce04942b2f395edf04f4cf10a))
* Added 'Further Reading' section in `README.md` ([`a94f083`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/a94f08332d7081e53a162d8ec09aaaa155c25f61))

## v3.0.2

Date: 2021-11-10 \
Tag: [`v3.0.2`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v3.0.2)

### Features

* [`MINI-754`](https://skyway.porsche.com/jira/browse/MINI-754) Introduce modern browser bundle via `browserslist` ([`!101`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/101))

## v3.0.1

Date: 2021-10-07 \
Tag: [`v3.0.1`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v3.0.1)

### Features

* [`CANVAS-48`](https://skyway.porsche.com/jira/browse/CANVAS-48) Set up package publishing to Porsche jFrog ([`!99`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/99))

### Documentation

* `README.md` files are moved to special `docs` folder ([`12b6a2b`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/12b6a2be91deba82e7298d9a5610f197746f918a))

## v3.0.0

Date: 2021-10-01 \
Tag: [`v3.0.0`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v3.0.0)

### Features

* [`CANVAS-243`](https://skyway.porsche.com/jira/browse/CANVAS-243) Rebuild as ES6 Module to use as Package ([`!98`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/98))

### Breaking Changes

* Refactor extension naming during registration ([`9054533`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/9054533605afa5cf9581df2409221dcba154f851))

### Fixes

* Library package `main` entry was wrong ([`7506645`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/750664545a1a2a0774560efc927fc22e81f55816))

### Documentation

* Useless `JSDocs` have been removed ([`e53b73d`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/e53b73d56c1fcc741ba3d0b284a30a3ba1ff2860))

## v2.2.9

Date: 2021-09-06 \
Tag: [`v2.2.9`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.2.9)

### DataLayer Updates

* PAGPCOM v92 (new property `applicationName`) ([`!97`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/97))

## v2.2.8

Date: 2021-07-19 \
Tag: [`v2.2.8`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.2.8)

### Fixes

* `ViewportTracker` default setting for `eventAction` is not `PAGPCOM` related anymore ([`f7fd65f`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/f7fd65fbfdd46bc11b3b2e6a90f2f37b0871db85))

### Tests

* `ViewportTracker` clean `eventAction` tests ([`6f884ba`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/6f884ba13df809f26d5579b8f1adee23836cade2))

### Documentation

* Several cleanups in documentations ([`!96`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/96))
* Add the `eventAction` setting to the `ViewportTracker` documentation ([`f9ecde5`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/f9ecde59d62836dae814b9b4e57532e501b09840))

## v2.2.7

Date: 2021-06-18 \
Tag: [`v2.2.7`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.2.7)

### DataLayer Updates

* PAGPCOM v85 (m-671 Range Indicator) ([`!95`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/95))

## v2.2.6

Date: 2021-05-28 \
Tag: [`v2.2.6`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.2.6)

### DataLayer Updates

* PAGPCOM v79 (PMEX Leasing Calculator II) ([`!94`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/94))

## v2.2.5

Date: 2021-05-26 \
Tag: [`v2.2.5`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.2.5)

### DataLayer Updates

* PAGPCOM v78 (PMEX Leasing Calculator) ([`!93`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/93))

## v2.2.4

Date: 2021-05-18 \
Tag: [`v2.2.4`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.2.4)

### DataLayer Updates

* PAGPCOM v76 ([`!92`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/92))

## v2.2.3

Date: 2021-05-05 \
Tag: [`v2.2.3`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.2.3)

### Features

* [`DLPCOM-492`](https://skyway.porsche.com/jira/browse/DLPCOM-492) Ensure IE11 compatibility of builds by targeting `es5` in webpack ([`!91`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/91))

## v2.2.2

Date: 2021-05-04 \
Tag: [`v2.2.2`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.2.2)

### Features

* DLPOCM-491 Only wanted props can be marked as mandatory for an event ([`!89`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/89))

### Documentation

* Confluence highway is skyway now ([`!90`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/90))
* [`DLPCOM-403`](https://skyway.porsche.com/jira/browse/DLPCOM-403) Clean up and rewrite POC ([`!88`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/88))
* Added POC to the `README.md` ([`f01af84`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/f01af84333b5e8f6750ed9e4d6a99a8cfbc2f62d))

## v2.2.1

Date: 2021-03-11 \
Tag: [`v2.2.1`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.2.1)

### DataLayer Updates

* PAGPCOM v69 ([`!87`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/87))

## v2.2.0

Date: 2021-03-03 \
Tag: [`v2.2.0`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.2.0)

### Fixes

* [`DLPCOM-418`](https://skyway.porsche.com/jira/browse/DLPCOM-418) `PageNameExtender`s `reduce` function had a wrong error message ([`!86`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/86))
* [`DLPCOM-460`](https://skyway.porsche.com/jira/browse/DLPCOM-460) Extension `Name`s should not be mangled in production ([`!85`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/85))

## v2.1.2

Date: 2021-02-05 \
Tag: [`v2.1.2`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.1.2)

### DataLayer Updates

* PAGPCOM v65 ([`!84`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/84))

## v2.1.1

Date: 2021-02-03 \
Tag: [`v2.1.1`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.1.1)

### Features

* Register setting `properties` of ViewportTracker can be function now ([`!83`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/83))

## v2.1.0

Date: 2021-02-02 \
Tag: [`v2.1.0`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.1.0)

### Fixes

* Validation was only done on mandatory properties ([`!82`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/82))

### DataLayer Updates

* PAGPCOM v64 ([`!81`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/81))

## v2.0.5

Date: 2021-01-29 \
Tag: [`v2.0.5`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.0.5)

### Features

* [`DLPCOM-435`](https://skyway.porsche.com/jira/browse/DLPCOM-435) `set` of `PageNameExtender` can keep the `extend` ([`!79`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/79))

* [`DLPCOM-435`](https://skyway.porsche.com/jira/browse/DLPCOM-435) `reduce` of `PageNameExtender` will keep the complete basic page name ([`9051249`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/9051249a9486d98b468de3434792f40ad38c0172))
* [`DLPCOM-435`](https://skyway.porsche.com/jira/browse/DLPCOM-435) `get` of `PageNameExtender` can return without values of `extend` ([`5e58219`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/5e5821919227041a4ecdc7ef85a91750261756e9))

### Tests

* [`DLPCOM-435`](https://skyway.porsche.com/jira/browse/DLPCOM-435) `PageNameExtender` will test now with the use of `extend` ([`f4662ca`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/f4662ca34ae161279998d9398192bae1868b044b))

### Documentation

* [`DLPCOM-435`](https://skyway.porsche.com/jira/browse/DLPCOM-435) Keep logic of `PageNameExtener` ([`!80`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/80))
* `FEATURE` prefix in commits of auto change log ([`!78`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/78))

## v2.0.4

Date: 2021-01-25 \
Tag: [`v2.0.4`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.0.4)

### Documentation

* Update and clean repository host ([`75be681`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/75be681da3a13257c75a459354e7ef821cdab381))

## v2.0.3

Date: 2021-01-25 \
Tag: [`v2.0.3`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.0.3)

### Features

* Full version and license comment in the output ([`!77`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/77))

### DataLayer Updates

* PAGPCOM v57 ([`!76`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/76))

## v2.0.2

Date: 2021-01-25 \
Tag: [`v2.0.2`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.0.2)

### Fixes

* Missing banner in minified versions ([`2947338`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/29473388ee7e777fe14df963c9bac057b87815c0))
* [`DLPCOM-438`](https://skyway.porsche.com/jira/browse/DLPCOM-438) Remove `console.log` ([`dab0ae5`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/dab0ae5e3ffe82f2b2d475bacb6e5e22b89934c8))

### Documentation

* Cleanup automatic change log ([`!75`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/75))

<!-- auto-changelog-above -->
## v2.0.1

Date: 2021-01-25 \
Tag: [`v2.0.1`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.0.1)

### Features

* [`DLPCOM-438`](https://skyway.porsche.com/jira/browse/DLPCOM-438) Performance improvements while using `flatten` ([`!74`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/74))
* [`DLPCOM-435`](https://skyway.porsche.com/jira/browse/DLPCOM-435) Add setting `pageIdAlwaysUpToDate` to `DefaultWebProperties` which defaults to `false` ([`!72`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/72))
* [`DLPCOM-128`](https://skyway.porsche.com/jira/browse/DLPCOM-128) Add `BaseExtension` to output ([`!71`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/71))

### Fixes

* Fix and clean up changelog ([`1375d36`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/1375d36697c8e78dfff7b6433ce2ff039448793c))
* [`DLPCOM-438`](https://skyway.porsche.com/jira/browse/DLPCOM-438) To not remove properties of type `array` ([`a77ad3d`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/a77ad3df7c17da3a6bc2c121cdebc7db8d9de613))

### Tests

* [`DLPCOM-438`](https://skyway.porsche.com/jira/browse/DLPCOM-438) Push also tests property type `array` now ([`9c554b9`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/9c554b99e62c98c372aff8285c7d53451a826027))

## v2.0.0

Date: 2020-12-14 \
Tag: [`v2.0.0`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v2.0.0)

### Features

* [`DLPCOM-418`](https://skyway.porsche.com/jira/browse/DLPCOM-418) New Extension PageNameExtender ([`!66`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/66))

### Breaking Changes

* To ensure importable releases the architecture of the import did change ([`!70`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/70))
* [`DLPCOM-335`](https://skyway.porsche.com/jira/browse/DLPCOM-335) `withBaseProps` is extension now ([`c106179`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/c106179e2c7faf764e3cf5d5766f155a2d2943f6))
* [`DLPCOM-335`](https://skyway.porsche.com/jira/browse/DLPCOM-335) No modules anymore (please implement in your project space) ([`5b522b2`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/5b522b2432b04a9181f7be154d8959185221cf8a))
* [`DLPCOM-335`](https://skyway.porsche.com/jira/browse/DLPCOM-335) No need for `GlobalDataLayer.default` anymore ([`06b5235`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/06b52356ed5195a2be07970d6bed36092b92586a))
* [`DLPCOM-418`](https://skyway.porsche.com/jira/browse/DLPCOM-418) Module PAGPCOM is using PageNameExtender now ([`60ebb12`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/60ebb12bcafa15ccda58337a879e40f3840a06c1))

### Fixes

* [`DLPCOM-428`](https://skyway.porsche.com/jira/browse/DLPCOM-428) Minimum time when enter `ViewportTracker` ([`!68`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/68))
* [`DLPCOM-335`](https://skyway.porsche.com/jira/browse/DLPCOM-335) Update all npm packages ([`03edab8`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/03edab8e4f028f306d0d55e9e1daac36bc89d0d5))
* Viewport Tracker `eventAction` was hard coded ([`b795394`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/b79539452b879e332d1b66c322c0027919279ea7))

### DataLayer Updates

* PAGPCOM v56 ([`!67`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/67))

### Tests

* `basicExtensionTest` accepts non `boolean` values as return type now ([`06500bb`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/06500bbfd52de71405cf8870d852b1e2054dc4b6))

### Documentation

* [`DLPCOM-335`](https://skyway.porsche.com/jira/browse/DLPCOM-335) Update documentations regarding breaking changes ([`fdb3083`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/fdb30835e8d82b728d24433a83d5d3284a45ef5f))
* Update typedoc and added Extensions and Modules to the docs ([`5e0235d`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/5e0235d411704a1e9da15525ace812874f29ddeb))

## v1.4.4

Date: 2020-12-02 \
Tag: [`v1.4.4`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v1.4.4)

### Features

* [`DLPCOM-280`](https://skyway.porsche.com/jira/browse/DLPCOM-280): Committing `dist` folder is only allowed on `master` branch. ([`!63`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/63))

### Fixes

* [`DLPCOM-378`](https://skyway.porsche.com/jira/browse/DLPCOM-378) set by default eventData parameter to an empty object... ([`!64`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/64))
* [`DLPCOM-378`](https://skyway.porsche.com/jira/browse/DLPCOM-378) set by default eventData parameter to an empty object because the rest of the methods expect always an object. ([`90047b2`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/90047b237956ba337a41087e2b58570b49298657))

### DataLayer Updates

* PAGPCOM v53 ([`!65`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/65))

## v1.4.3

Date: 2020-11-27 \
Tag: [`v1.4.3`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v1.4.3)

### Features

* [`DLPCOM-389`](https://skyway.porsche.com/jira/browse/DLPCOM-389) Allow to push properties that are not in the `eventMatrix` ([`!60`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/60))

### Breaking Changes

* [`DLPCOM-389`](https://skyway.porsche.com/jira/browse/DLPCOM-389) Add new property allowUnknownPropsOnPush to the GDL settings and convert the third param of push method into a settings object. ([`7df25da`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/7df25dade3bac20ee0d09fb0648a69fd07154f47))

### DataLayer Updates

* PAGPCOM v49 ([`!58`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/58))

### Tests

* [`DLPCOM-385`](https://skyway.porsche.com/jira/browse/DLPCOM-385) `tests` folder is now also linted ([`!61`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/61))
* [`DLPCOM-283`](https://skyway.porsche.com/jira/browse/DLPCOM-283) Added ViewportTracker visual element tracking tests ([`!57`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/57))

### Documentation

* [`DLPCOM-283`](https://skyway.porsche.com/jira/browse/DLPCOM-283) Documentation of Extension `ViewportTracker` ([`!59`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/59))

## v1.4.2

Date: 2020-11-24 \
Tag: [`v1.4.2`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v1.4.2)

### Features

* [`DLPCOM-191`](https://skyway.porsche.com/jira/browse/DLPCOM-191) Load event matrix from different projects ([`!56`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/56))

### Fixes

* PAGPCOM Module missing type conversion ([`4c8e968`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/4c8e96846bb88da6569316240c50ac1cce9cac7a))

### Documentation

* Important changes to the `eventMatrix` handling ([`ce9bfbd`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/ce9bfbd9e02fb8d54ea79ccccab46cb3edf03220))

## v1.4.1

Date: 2020-11-23 \
Tag: [`v1.4.1`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v1.4.1)

### Features

* [`DLPCOM-324`](https://skyway.porsche.com/jira/browse/DLPCOM-324) Auto remove props with unacceptable values ([`!51`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/51))

### Fixes

* [`DLPCOM-283`](https://skyway.porsche.com/jira/browse/DLPCOM-283) ViewportTracker unregister element before register ([`!53`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/53))

### DataLayer Updates

* PAGPCOM v47 ([`!55`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/55))

### Tests

* Fix the baseProps tests ([`d3899b3`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/d3899b3e29b69aa0631db7686ffe745b153ab93a))

### Documentation

* Clean the formatting of the `README.md` ([`8e50847`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/8e508476ed0971e05223163ac291faaafb4b7db9))

## v1.4.0

Date: 2020-11-20 \
Tag: [`v1.4.0`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v1.4.0)

### Features

* [`DLPCOM-283`](https://skyway.porsche.com/jira/browse/DLPCOM-283) New extension `ViewportTracker`, that observes the visibility of DOM elements ([`!50`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/50))

## v1.3.4

Date: 2020-11-19 \
Tag: [`v1.3.4`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v1.3.4)

### Fixes

* `release` and `release-fastlane` arguments are now forwareded from `dotenv` ([`adca5dd`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/adca5dd2b46c050bf417f757a521cdcffc02954c))

## v1.3.3

Date: 2020-11-16 \
Tag: [`v1.3.3`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v1.3.3)

### Breaking Changes

* release-it does now have `skipChecks` to `false` ([`5d292ef`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/5d292ef31facc5baf0bb57d969b5c8d2375e1970))

### Fixes

* [`DLPCOM-279`](https://skyway.porsche.com/jira/browse/DLPCOM-279) Remove prefixes from auto `CHANGELOG.md` ([`!46`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/46))

### Documentation

* [`DLPCOM-279`](https://skyway.porsche.com/jira/browse/DLPCOM-279) Release management and auto changelog ([`!48`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/48))
* [`DLPCOM-282`](https://skyway.porsche.com/jira/browse/DLPCOM-282) Adding documentation for creating, register and using extensions ([`!47`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/47))
* Reorder `README.md` and add TOC ([`7ce7421`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/7ce742185ce35c5b26d3417b6333e88d34675682))
* Update npm tasks documentation ([`e931b59`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/e931b59e1677e258067c1b73379b937112cc652c))
* Update existing changelog to remove prefixes and typos ([`581aab1`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/581aab143f5994f766603aeeb84640f0468c06f4))
* Use auto TOC for `README.md` and add it to the release pipeline ([`4304fee`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/4304feeac6d9f8d086187ca382e902ef07399d41))

## v1.3.2

Date: 2020-11-12 \
Tag: [`v1.3.2`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v1.3.2)

### Fixes

* [`DLPCOM-279`](https://skyway.porsche.com/jira/browse/DLPCOM-279) Release changelog was not using unreleased ([`66cd8e4`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/66cd8e4586cfd347d502a0bb2873b384cac7bb78))

### Documentation

* [`DLPCOM-279`](https://skyway.porsche.com/jira/browse/DLPCOM-279) Add upcoming version for unreleased to use in release changelog ([`b2a96ff`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/b2a96ff4a02157b5597d66e6c62ed6f09aecf743))

## v1.3.1

Date: 2020-11-12 \
Tag: [`v1.3.1`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v1.3.1)

### Fixes

* [`DLPCOM-282`](https://skyway.porsche.com/jira/browse/DLPCOM-282) Optimize `registerExtension` (no variable naming, no interface) ([`!42`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/42))
* [`DLPCOM-279`](https://skyway.porsche.com/jira/browse/DLPCOM-279) auto-changelog template needs combined data ([`34a75d3`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/34a75d31816504064da47ec5abadb80a60655a82))
* [`DLPCOM-279`](https://skyway.porsche.com/jira/browse/DLPCOM-279) auto-changelog in release task missed `--stdout` option ([`008ea9a`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/008ea9a72b402db16a0ea6f6c95dca93ec2eeda7))
* [`DLPCOM-279`](https://skyway.porsche.com/jira/browse/DLPCOM-279) Release automation now uses `--unreleased-only` in for `auto-changelog` ([`d4a9b91`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/d4a9b91135cfd1a5763271db59678671e73a3976))

### DataLayer Updates

* PAGPCOM v45 ([`!45`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/45))

### Tests

* Write shared tests for Extensions ([`b8ee4b0`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/b8ee4b023904cd82da449565bb2ae5356a3f47b1))

### Documentation

* [`DLPCOM-279`](https://skyway.porsche.com/jira/browse/DLPCOM-279) Change prefix `EXCEL: ` to `CSV: ` ([`!44`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/44))
* [`DLPCOM-279`](https://skyway.porsche.com/jira/browse/DLPCOM-279) Add auto generated `CHANGELOG.md` to the release automation ([`!43`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/43))
* Add semi manual changelog until v1.3.0 ([`36f27e2`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/36f27e21a2dec4ddabcedd0b4a5865d01e527477))
* README.md was cleaned up ([`b70b801`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/b70b801a0fb37edeaf89e369569694328b212345))
* Add documentation for commit prefixes ([`fe5947b`](https://pag-git.bb-k.net/porsche/global-data-layer/commit/fe5947b8c47300dda87429806e9c2addb58caba8))

## v1.3.0

Date: 2020-11-10 \
Tag: [`v1.3.0`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v1.3.0) \
Diff: [`previous..v1.3.0`](http://pag-git.bb-k.net/porsche/global-data-layer/compare/v1.2.1...v1.3.0)

### Features

* [`DLPCOM-279`](https://skyway.porsche.com/jira/browse/DLPCOM-279) Release Automation ([`!40`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/40))
* [`DLPCOM-282`](https://skyway.porsche.com/jira/browse/DLPCOM-282) Introduce Extensions ([`!39`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/39))
* [`DLPCOM-217`](https://skyway.porsche.com/jira/browse/DLPCOM-217) `baseWebProps` now calculates `visitor.deviceBrowserBreakpoint` based on setting ([`!37`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/37))
* [`DLPCOM-216`](https://skyway.porsche.com/jira/browse/DLPCOM-216) Add possibility to transfer settings to a module ([`!36`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/36))

### Fixes
* [`DLPCOM-282`](https://skyway.porsche.com/jira/browse/DLPCOM-282) Register extension tests ([`!41`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/41))

### Documentation

* [`DLPCOM-21`](https://skyway.porsche.com/jira/browse/DLPCOM-21) Add commit and branching conventions ([`!35`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/35))

## v1.2.1

Date: 2020-11-04 \
Tag: [`v1.2.1`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v1.2.1) \
Diff: [`previous..v1.2.1`](http://pag-git.bb-k.net/porsche/global-data-layer/compare/v1.2.0...v1.2.1)

### Features

* [`DLPCOM-219`](https://skyway.porsche.com/jira/browse/DLPCOM-219) `baseWebProps` adds `visitor.deviceType` ([`!33`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/33))

## Fixes

* DEV Server Build  Failures ([`!34`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/34))

## v1.2.0

Date: 2020-11-03 \
Tag: [`v1.2.0`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v1.2.0) \
Diff: [`previous..v1.2.0`](http://pag-git.bb-k.net/porsche/global-data-layer/compare/v1.1.1...v1.2.0)

### Features

* [`DLPCOM-218`](https://skyway.porsche.com/jira/browse/DLPCOM-218) Automatically add `context.eventAction` in pushes to pagData ([`!31`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/31))

## v1.1.1

Date: 2020-10-28 \
Tag: [`v1.1.1`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v1.1.1) \
Diff: [`previous..v1.1.1`](http://pag-git.bb-k.net/porsche/global-data-layer/compare/v1.1.0...v1.1.1)

### Features

* Better Build Pipeline ([`!30`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/30))

## v1.1.0

Date: 2020-10-26 \
Tag: [`v1.1.0`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v1.1.0) \
Diff: [`previous..v1.1.0`](http://pag-git.bb-k.net/porsche/global-data-layer/compare/v1.0.0...v1.1.0)

### DataLayer Updates

* PAGPCOM v38 ([`!29`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/29))

## v1.0.0

Date: 2020-10-20 \
Tag: [`v1.0.0`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v1.0.0) \
Diff: [`previous..v1.0.0`](http://pag-git.bb-k.net/porsche/global-data-layer/compare/v0.0.8...v1.0.0)

### Features

* New Matrix structure and matrix by setting  ([`!19`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/19))
* Include babel to transpile the code to ES5 ([`!27`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/27))
* [`DLPCOM-34`](https://skyway.porsche.com/jira/browse/DLPCOM-34) Introduce mandatory properties ([`!23`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/23))
* [`DLPCOM-29`](https://skyway.porsche.com/jira/browse/DLPCOM-29) Introduce default event properties ([`!22`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/22))
* [`DLPCOM-28`](https://skyway.porsche.com/jira/browse/DLPCOM-28) Manually load modules by extracting them from the core package ([`!21`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/21))
* [`DLPCOM-27`](https://skyway.porsche.com/jira/browse/DLPCOM-27) Introduce test and prod version ([`!20`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/20))
* Introduce `webBaseProps` for modules ([`!17`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/17))
* Give modules access to the `utils` library ([`!16`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/16))
* Use settings object in the `constructor` ([`!15`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/15))

### DataLayer Updates

* Generate several ([`!28`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/28))

### Tests

* Improve the assertion of test in order to get better error messages ([`!26`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/26))

### Documentation

* [`DLPCOM-30`](https://skyway.porsche.com/jira/browse/DLPCOM-30) Update documentation and add JSDocs + comments ([`!24`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/24))

## v0.0.8

Date: 2020-09-01 \
Tag: [`v0.0.8`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v0.0.8) \
Diff: [`previous..v0.0.8`](http://pag-git.bb-k.net/porsche/global-data-layer/compare/v0.0.7...v0.0.8)

### DataLayer Updates

* Update EventScopesMatrix.json and interfaces ([`!14`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/14))

## v0.0.7

Date: 2020-08-28 \
Tag: [`v0.0.7`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v0.0.7) \
Diff: [`previous..v0.0.7`](http://pag-git.bb-k.net/porsche/global-data-layer/compare/v0.0.6...v0.0.7)

### Features

* Update PCOM module because of structure changes in data layer Excel v30 ([`!13`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/13))
* Add lint-staged to run the linter commands on staged files ([`!10`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/10))

### Fixes

* lint-staged // Second command execution failed. ([`!11`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/11))

### Tests

* Add unit tests ([`!12`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/12))

## v0.0.6

Date: 2020-08-26 \
Tag: [`v0.0.6`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v0.0.6) \
Diff: [`previous..v0.0.6`](http://pag-git.bb-k.net/porsche/global-data-layer/compare/v0.0.5...v0.0.6)

### Features

* Update PCOM module to match structure changes in data layer Excel ([`!9`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/9))

## v0.0.5

Date: 2020-08-26 \
Tag: [`v0.0.5`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v0.0.5) \
Diff: [`previous..v0.0.5`](http://pag-git.bb-k.net/porsche/global-data-layer/compare/v0.0.2...v0.0.5)

### Features

* Add debug mode ([`!8`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/8))
* [`DLPCOM-16`](https://skyway.porsche.com/jira/browse/DLPCOM-16) Add modules and the first module PCOM ([`!5`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/5))

### Fixes

* Several eslint problems ([`!6`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/6))

## Docs

* Add JSDoc and package `typedoc` to create comment based documentation ([`!4`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/4))
* Add README.md and `GDL_POC.html` integration proof of concept ([`!3`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/3))

## v0.0.2

Date: 2020-08-26 \
Tag: [`v0.0.2`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v0.0.2) \
Diff: [`previous..v0.0.2`](http://pag-git.bb-k.net/porsche/global-data-layer/compare/v0.0.1...v0.0.2)

### DataLayer Updates

* Update EventScopesMatrix.json

## v0.0.1

Date: 2020-08-26 \
Tag: [`v0.0.1`](http://pag-git.bb-k.net/porsche/global-data-layer/tags/v0.0.1) \
Diff: [`previous..v0.0.1`]()

### Features

* Core library ([`!2`](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests/2))