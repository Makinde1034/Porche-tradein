# Contribution

Here is all the information you need to work on the library.

## Contents

<!-- toc -->

- [Project structure](#project-structure)
- [Environment Config](#environment-config)
- [`npm` Config File](#npm-config-file)
- [`npm` Tasks](#npm-tasks)
  * [Test](#test)
  * [Format and Lint](#format-and-lint)
  * [Release](#release)
  * [Build](#build)
    + [Build Steps](#build-steps)
  * [Pre Builds](#pre-builds)
- [Pre Commit Hooks](#pre-commit-hooks)
- [Naming Conventions](#naming-conventions)
  * [Branch](#branch)
  * [Commits](#commits)
  * [Merge Requests](#merge-requests)
  * [Auto Changelog Prefixes](#auto-changelog-prefixes)
- [Create a release](#create-a-release)

<!-- tocstop -->

## Project structure

* [`/bin`](bin) Contains NodeJS scripts for internal development use.
* [`/dist`](dist) The build folder for production.
  - [`/bundle`](dist/bundle) Use these files as a ES5 bundle on your page.
  - [`/module`](dist/module) Use this as a ES6 module as an import to your code.
  - [`/types`](dist/types) Use these types in your TypeScript application.
* [`/docs`](docs) Add or adapt additional documentation files.
* [`/examples`](examples) The example file to see the library working. You can use it as well to test the builds quickly.
* [`/src`](src) The code of the library.
  - [`/Extensions`](src/Extensions) Find BaseExtension and all global available extensions here.
  - [`/GlobalDataLayer`](src/GlobalDataLayer) The GlobalDataLayer core class.
  - [`/Types`](src/Types) Find global types here.
  - [`/Utils`](src/Utils) Find utils like the validator here.
* [`/tests`](tests) Contains all the unit tests for the library.
* [`/webpack`](webpack) Contains the webpack config files.

In the root of the project you can find the config files for 
* [auto-changelog]
* [@babel]
* [browserlist]
* [eslint]
* [jest]
* [prettier]
* [release-it]
* [typescript]

## Environment Config

The environment configuration file `.env` is needed if you want to do a release via the `release` script. It contains an 
authentication token `GITLAB_TOKEN` to the UDG GitLab. 

```
GITLAB_TOKEN="XXXXXXXXXXXXXXXXX"
```

## `npm` Config File

The `npm` configuration file `.npmrc` is needed if you want to do a release via the `release` script. It contains an
authentication data to the Porsche jFrog package manager.

```
@porsche:registry=https://porscheui.jfrog.io/porscheui/api/npm/npm-local/
//porscheui.jfrog.io/porscheui/api/npm/npm-local/:_password=[user.passwordhash]
//porscheui.jfrog.io/porscheui/api/npm/npm-local/:username=[user.name]
//porscheui.jfrog.io/porscheui/api/npm/npm-local/:email=[user.email]
//porscheui.jfrog.io/porscheui/api/npm/npm-local/:always-auth=true
```

## `npm` Tasks

### Test

* **dev**  
  Creates a web server to test the changes in your browsers `console`.

- **test**  
  Execute the tests that are under the folder [`/tests`](tests).

### Format and Lint

* **lint**  
  Check if there are eslint errors or bad formatted files in the [`/src`](src)
  folder.
* **format**  
  Format all the files according to the eslint/prettier rules.

### Release

* **release**  
  Step by step controlled release. Asks for a new version number, does a build and generates changelog. Will push the
  changes, release everything to gitlab and do a `npm publich`. Also see [Release Management] on Confluence.
* **release-fastlane**  
  Does the same as `release` but will only ask for the new version number.

### Build

_The following tasks are also part of the release pipeline._

* **build** \
  Generates the complete build output for development and production environment.

#### Build Steps

* **build-bundle**  
  Generates the _non minified_ and _minfied_ of the bundles (two versions, also see [`.browserslistrc`](.browserslistrc)):
  * `GlobalDataLayer.main.js`
    A bundle for modern web browsers.
  * `GlobalDataLayer.main.legacy.js`
    A bundle for legacy web browsers, which leads to a bigger file size.
* **build-module**  
  Generates the _non minified_ ES6 module version in [`/dist/module`](dist/module).

### Pre Builds

_The following tasks are also part of the release pipeline._

* **changelog**  
  Updates the changelog by using [`git log`](https://git-scm.com/docs/git-log) for released changes. Also
  see [Naming Conventions](#naming-conventions) and [Auto Changelog Prefixes](#auto-changelog-prefixes).
* **readme-toc**  
  Updates the TOC in `README.md`, `CONTRIBUTING.md` and all the `*.md` files the [`/docs`](docs) folder.

## Pre Commit Hooks

There are two _pre-commit hooks_

1. Checks if all the files have the proper format. So please set up your eslint and prettier properly.
1. Runs all the tests inside [`/tests`](tests) folder. Please make sure all the test succeed, otherwise you will not able
   to commit.

If you doubt which of these tests failed, you can run them separately(`npm run lint`
or `npm run test`).

## Naming Conventions

### Branch

For creating branches and there naming conventions we created a [Branching and Merge Concept] in our Confluence documentation
section.

### Commits

For the `commits` we have the following convention:

`[CHANGELOG_PREFIX][TICKET_ID] [SHORT_SUMMARY_OF_THE_CHANGES_DONE]`

Please keep the summary very short. You can also write a body message for some more explanation.

If a commit should be part of the automatic generated [`CHANGELOG.md`](CHANGELOG.md) you can also use the given
[prefixes](#auto-changelog-prefixes).

> (!) Please note: Most of the automated changelog should come from the Merge Requests (which have a naming convention also). 
> So please only add these prefixes if you have important log entries that are inside a bigger change.

### Merge Requests

For the naming conventions of
[merge requests](https://pag-git.bb-k.net/porsche/global-data-layer/merge_requests) we created a
[Branching and Merge Concept] in our Confluence documentation section.

All merge request are part of the automatic generated [`CHANGELOG.md`](CHANGELOG.md). You can also use the given
[prefixes](#auto-changelog-prefixes) to define a category. Uncategorized merge requests are always _features_.

> (!) Merge Backs must always be done via a Merge Request and need to be [prefixed](#auto-changelog-prefixes) to exclude them 
> from the automatic changelog.

### Auto Changelog Prefixes

| Prefix                   | Purpose                                                              | Example                                                                |
| ------------------------ | -------------------------------------------------------------------- | ---------------------------------------------------------------------- |
|                          | **Merge request** with no prefix are always categorized as features. | _DLPCOM-123 With `crazyMethod` we can now solve the balanced problem_  |
| `MERGE BACK: ` or `MB: ` | A merge back **merge request** must be excluded from the changelog.  | _MB: master into feature/DLPCOM-123_add-crazy-method_                  |
| `FEATURE: `              | Changes to the code that are new features.                           | _FEATURE: DLPCOM-123 `crazyMethod` can also freak out now_             |
| `BREAKING CHANGE: `      | Changes to the code that are important for others.                   | _BREAKING CHANGE: DLPCOM-123 `crazyMethod` has settings parameter now_ |
| `BUGFIX: `               | If you are fixing a bug please also mention the ticket then.         | _BUGFIX: DLPCOM-123 `crazyMethod` fails when `settings` are undefined_ |
| `TEST: `                 | If you have adapted or added an **important** `jest` test.           | _TEST: Added test for `crazyMethod`_                                   |
| `DOCS: `                 | If you have adapted or added an **important** documentation.         | _DOCS: Added documentation for `crazyMethod`_                          |

## Create a release

The process to create a new release is documented in detail on the [Release Management] Confluence page.

Here is a short version:

* Releases (or builds) are only allowed to be generated and pushed in the `master`. Therefore, you need to be a maintainer of
  the project.
* Use the one of the [tasks](#npm-tasks) in the [release](#release) section like `relese-fastlane`.
* If you have doubts, use `release` command and check the files before they are committed, tagged, pushed and released.
* Make sure you have set up the gitlab token in a `.env` file for the gitlab release. 
  Also see [Environment Config](#environment-config).
* Make sure you have set up the jFrog registry correctly in the `.npmrc` file for the package release to jFrog. 
  Also see [`npm` Config File](#npm-config-file).

[Branching and Merge Concept]: https://skyway.porsche.com/confluence/x/vrJCCw
[Release Management]: https://skyway.porsche.com/confluence/x/NchCCw
[DataLayer Excel]: https://skyway.porsche.com/confluence/x/IJL9CQ
[auto-changelog]: https://www.npmjs.com/package/auto-changelog
[@babel]: https://babeljs.io/
[browserlist]: https://www.npmjs.com/package/browserlist 
[eslint]: https://www.npmjs.com/package/eslint 
[jest]: https://www.npmjs.com/package/jest 
[prettier]: https://www.npmjs.com/package/prettier 
[release-it]: https://www.npmjs.com/package/release-it 
[typescript]: https://www.typescriptlang.org/
