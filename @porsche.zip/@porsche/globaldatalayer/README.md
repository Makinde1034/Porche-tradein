# Global Data Layer Library Documentation

**General purpose**: Provide a way to handle and push events to the global array
_pagData_ in a more effective way.

## Contents

<!-- toc -->

- [Integration](#integration)
  * [NPM (jFrog)](#npm-jfrog)
  * [Bundle](#bundle)
  * [Already Available?](#already-available)
- [Usage](#usage)
- [Validation](#validation)
- [Extensions](#extensions)
  * [Available Extensions](#available-extensions)
- [Further Reading](#further-reading)
- [Contribution](#contribution)

<!-- tocstop -->

## Integration

Integrate the library as ES6 module.

### NPM (jFrog)

```shell
npm install @porsche/globaldatalayer --save
```

Make sure you added `@porsche` to your `.npmrc` file and did log in to your Porsche jFrog account.
```
@porsche:registry=https://porscheui.jfrog.io/porscheui/api/npm/npm/`
```

### Bundle

You can also use one of our bundles (also see [`.browserslistrc`](.browserslistrc)):
* [`GlobalDataLayer.main.min.js`](dist/bundle/GlobalDataLayer.main.min.js)  
A bundle for modern web browsers.
* [`GlobalDataLayer.main.legacy.min.js`](dist/bundle/GlobalDataLayer.main.legacy.min.js)  
A bundle for legacy web browsers, which has a bigger file size.

### Already Available?

On the most porsche.com pages you can use the already available global instance with already
active [`DefaultWebProperties`](docs/Extensions/DefaultWebProperties/README.md)
Extension and other [DefaultProperties](docs/GlobalDataLayer/README.md#setdefaultproperties).

## Usage

Instantiate by calling the constructor.

```javascript
import {GlobalDataLayer, DefaultWebProperties, ViewportTracker} from '@porsche/globaldatalayer';

const GDL = new GlobalDataLayer(mySettings);
// ...
GDL.push(myEventName, myEventProperties);
```

Please find a detailed documentation of the basic functionality of the `GlobalDataLayer` class in the 
[documentaion](docs/GlobalDataLayer/README.md).

You can also find an [`POC`](examples/POC/index.html) under [`/examples`](examples)
to see the library and some [Extensions](#extensions) working.

## Validation

The `GlobalDataLayer` is able to validate the pushed data. This can help you to prevent false data.

If you want to know how to enable this feature and get some more information, please see the documentation of the 
[Validation](docs/Utils/Validation/README.md) utility. 

## Extensions

Extensions are can help you to run some logic across the `GlobalDataLayer`, providing a way to track certain things without 
the need to create the same logic over and over again.

If you want to know more about extensions, please see the [`Extensions`](docs/Extensions/README.md) documentation.

If you want to know how to write your own extension, please also see the documentation of the
[`BaseExtension`](docs/Extensions/BaseExtension/README.md) class.

### Available Extensions

There are some shared extensions already available.

- [`DefaultWebProperties`](docs/Extensions/DefaultWebProperties/README.md):
  To handle default properties, that could be used in every web application.
- [`PageNameExtender`](docs/Extensions/PageNameExtender/README.md):
  To handle the page name in single page applications or modules
- [`ViewportTracker`](docs/Extensions/ViewportTracker/README.md):
  To track DOM elements come into view

## Further Reading

For detailed information about the different features please see the please see the `README.md` files of the 
[`/docs`](/docs) section.

- [GlobalDataLayer](docs/GlobalDataLayer/README.md)
- Utils
  * [Utils/Validation](docs/Utils/Validation/README.md)
- [Extensions](docs/Extensions/README.md)
  * [BaseExtension](docs/Extensions/BaseExtension/README.md)
  * [DefaultWebProperties](docs/Extensions/DefaultWebProperties/README.md)
  * [PageNameExtender](docs/Extensions/PageNameExtender/README.md)
  * [ViewportTracker](docs/Extensions/ViewportTracker/README.md)

## Contribution

If you want to contribute to the library repository, please see the [_CONTRIBUTING.md_](CONTRIBUTING.md).
