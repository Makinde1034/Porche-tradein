# Base Extension

This is the base class for an extension and all extensions must extend 
this `BaseExtension` class, the respective `BaseExtensionInterface` and the 
`BaseExtensionSettingsInterface`.

## Contents

<!-- toc -->

- [Usage](#usage)
  * [Extend of a `SettingsInterface`](#extend-of-a-settingsinterface)
  * [Extend of an Extension Class](#extend-of-an-extension-class)
- [Name and `name` Setting](#name-and-name-setting)
- [`initialize` Method](#initialize-method)
- [`parseSettings` Method](#parsesettings-method)

<!-- tocstop -->

## Usage

### Extend of a `SettingsInterface`

```typescript
interface MyOwnExtensionSettingsInterface
  extends BaseExtensionSettingsInterface {
  importantSetting: boolean;
  optionalSetting?: string;
}
```

### Extend of an Extension Class

```typescript
class MyOwnExtension extends BaseExtension {
  protected basicSettings: MyOwnExtensionSettingsInterface = {
    name: 'MyOwnExtension',
    importantSetting: true,
    optionalSetting: '/',
  };
  
  constructor(
    protected GDLInstance: GlobalDataLayer,
    settings: MyOwnExtensionSettingsInterface = {}
  ) {
    super(GDLInstance, settings);
    this.initialize(GDLInstance, settings);
    // ...
  }
  
  // ...
}
```

## Name and `name` Setting

It is important to name your extension via the `basicSettings`. The name will be taken during the registration on the 
`GlobalDataLayer` instance. So you will call the extension with this defined name. During initialization it is possible to 
overwrite the `name` property in the settings object.

```javascript
// Registration
GDL.registerExtension(new MyOwnExtension(
  GDL,
  {
    eventAction: 'MyOwnEventPurpose',
  }
));

// Calling a method of the extension
GDL.ext.MyOwnExtension.myOwnExtensionMethod();
```

The default behavior does not except to overwrite extensions with the same name during registration by default. But you 
can register an extension of the same type with different names.

```javascript
// EDGE CASE: Registration of another extension of the same type
GDL.registerExtension(new MyOwnExtension( // Classname is still the same
  GDL,
  {
    name: 'MyOwnExtensionRenamed', // Please note renaming
    eventAction: 'MyOwnEventPurpose',
  },
));

// Calling method of the renamed extension
GDL.ext.MyOwnExtensionRenamed.myOwnExtensionMethod(); // ext.[NAME] is renamed

// Name property
console.log(GDL.ext.MyOwnExtension.Name) // MyOwnExtension
console.log(GDL.ext.MyOwnExtensionRenamed.Name) // MyOwnExtensionRenamed
```

## `initialize` Method

Initialize has to be called from every child class constructor. You can read about that pattern and why it needs to be used 
here on this [StackOverflow](https://stackoverflow.com/questions/43595943/#answer-43595944) article.

```typescript
class MyOwnExtension extends BaseExtension {
  constructor(
    protected GDLInstance: GlobalDataLayer,
    settings: Record<string, unknown> = {}
  ) {
    super(GDLInstance, settings);
    this.initialize(GDLInstance, settings);
  }

  protected initialize(
    GDLInstance: GlobalDataLayer,
    settings: Record<string, unknown> = {}
  ) {
    super.initialize(GDLInstance, settings);
    // add more code that has to be called 
    // while the child class gets initialized
  }
}
```

The basic initialize method does call the `parseSettings` method.

## `parseSettings` Method

To parse and adjust settings after the merge with `basicSettings` is done. Override this function if needed.

```typescript
class MyOwnExtension extends BaseExtension {
  protected parseSettings(
    settings: MyOwnExtensionSettingsInterface
  ): MyOwnExtensionSettingsInterface {  
    if ((/^(Hello|Hola|Bonjour) .*/).test(settings.optionalSetting)) {
      settings.optionalSetting = this.basicSettings.optionalSetting;
    }
  
    return settings;
  }
}
```
