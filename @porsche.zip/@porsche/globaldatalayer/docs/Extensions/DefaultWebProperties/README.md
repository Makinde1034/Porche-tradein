# DefaultWebProperties

Extension Class for handling default properties, that could/should be used in web applications.

## Contents

<!-- toc -->

- [Usage](#usage)
  * [Register and Settings](#register-and-settings)
  * [Calling Methods](#calling-methods)
- [The Web Base Properties](#the-web-base-properties)
- [Methods](#methods)
  * [`get`](#get)
  * [`with`](#with)

<!-- tocstop -->

## Usage

### Register and Settings

You can register with optional breakpoints.

```javascript
GDL.registerExtension(
  new PageNameExtender(globalDataLayerInstance, {
    breakpoints: [320, 640, 960, 1024]
  })
);
```

### Calling Methods

Like in every extension you now can call your extension methods via the `GDL.ext` object.

```javascript
GDL.ext.DefaultWebProperties.with({
  context: { eventAction: 'My_Global_Load' },
});
```

## The Web Base Properties

The object contains these properties.

| Property                         | Type                          | Comment                                                                       |
| -------------------------------- | ----------------------------- | ----------------------------------------------------------------------------- |
| context                          |                               |                                                                               |
| context.timestamp                | Executed on every `GDL.push`. |                                                                               |
| context.server                   | Executed on every `GDL.push`. |                                                                               |
| pageExperience                   |                               |                                                                               |
| pageExperience.pageId            | Cached                        |                                                                               |
| visitor                          |                               |                                                                               |
| visitor.deviceBrowserHeight      | Executed on every `GDL.push`. |                                                                               |
| visitor.deviceBrowserOrientation | Executed on every `GDL.push`. |                                                                               |
| visitor.deviceBrowserWidth       | Executed on every `GDL.push`. |                                                                               |
| visitor.deviceType               | Cached                        |                                                                               |
| visitor.useragent                | Cached                        |                                                                               |
| visitor.deviceBrowserBreakpoint  | Executed on every `GDL.push`. | This is only available if you have set the breakpoint config in the settings. |

## Methods

### `get`

Get the properties object to use it in a `GDL.setDefaultProperties` call

```javascript
GDL.ext.DefaultWebProperties.get();
```

### `with`

Use the `with` method to extend the values of the `get` method with some more data.

```javascript
GDL.ext.DefaultWebProperties.with({
  context: {
    eventAction: 'My_Global_Load',
  }
});
```
