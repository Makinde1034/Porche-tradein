# PageNameExtender

Extension Class for handling sub-page levels in single page applications. For this it is often necessary to extend the
current property `pageExperience.pageName`. With the `PageNameExtender` you are able to store and handle the current
level of the page name.

> Please note: In most single page applications you should use your router for this. This is just a workaround for
> single page modules without a router functionality.

## Contents

<!-- toc -->

- [Usage](#usage)
  * [Register and Settings](#register-and-settings)
  * [Calling Methods](#calling-methods)
- [Methods](#methods)
  * [`set`](#set)
  * [`get`](#get)
  * [`extend`](#extend)
  * [`reduce`](#reduce)
  * [`prepend` and `append`](#prepend-and-append)

<!-- tocstop -->

## Usage

### Register and Settings

You can register with an initial page name and a separator (default `'/'`).

> You can also set your page name by using the `set` method later.  
> But please note: The separator has to be set in the settings of the constructor. It cannot be changed later.

```javascript
GDL.registerExtension(
  new PageNameExtender(GDL, {
    initialPageName: 'mypagename',
    separator: '/'
  })
);
```

### Calling Methods

Like in every extension you now can call your extension methods via the `GDL.ext` object.

```javascript
GDL.ext.PageNameExtender.set('mypagename');
```

## Methods

All methods will always return the _current_ or _new_ or _modified_ page name.

### `set`

Set or reset the page name. Do this if you do not want to use the constructor settings or when you have a complete new
page name.

```javascript
GDL.ext.PageNameExtender.set('mypagename'); // --> mypagename
```

The `set` method can also be used to set directly multiple levels.

```javascript
GDL.ext.PageNameExtender.set(['mypagename', 'sublevel1']); // --> mypagename/sublevel1
// is the same as ...
GDL.ext.PageNameExtender.set('mypagename/sublevel1'); // --> mypagename/sublevel1
// ... when the default separator is used
```

In the default the `set` method will overwrite everything, also the parts, that were added by `extend`. You can keep
them by adding `true` as the second argument.

```javascript
GDL.ext.PageNameExtender.set('my_OLD_pagename/KEEPLEVEL', true); // --> my_OLD_pagename/KEEPLEVEL
GDL.ext.PageNameExtender.extend('sublevel2'); // --> my_OLD_pagename/KEEPLEVEL/sublevel2
GDL.ext.PageNameExtender.set('my_NEW_pagename/KEEPLEVEL1/KEEPLEVEL2', true); // --> my_NEW_pagename/KEEPLEVEL1/KEEPLEVEL2/sublevel2
```

### `get`

Use the `get` method to get the current stored page name as a joined string.

```javascript
GDL.ext.PageNameExtender.get(); // --> mypagename

GDL.ext.PageNameExtender.set(['mypagename', 'sublevel1']);
GDL.ext.PageNameExtender.get(); // --> mypagename/sublevel1
```

Use the `basePageNameOnly` argument of `get` method to only get the current basic page name as a joined string without
the values that were added by `extend`.

```javascript
GDL.ext.PageNameExtender.get(); // --> mypagename

GDL.ext.PageNameExtender.set(['mypagename', 'sublevel1']);
GDL.ext.PageNameExtender.get(); // --> mypagename/sublevel1
GDL.ext.PageNameExtender.get(true); // --> mypagename
```

### `extend`

If a sub-level is active, you should permanently extend the current page name.

```javascript
GDL.ext.PageNameExtender.get(); // --> mypagename
GDL.ext.PageNameExtender.extend('sublevel1'); // --> mypagename/sublevel1
```

You can also extend with multiple sub-levels at once.

```javascript
GDL.ext.PageNameExtender.extend(['sublevel1', 'sublevel2']); // --> mypagename/sublevel1/sublevel2
// is the same as ...
GDL.ext.PageNameExtender.extend(['sublevel1/sublevel2']); // --> mypagename/sublevel1/sublevel2
```

### `reduce`

Is the opposite of `extend` and will permanently reduce the current page name by a number of levels.

> Please note: You can never remove the root level.

```javascript
GDL.ext.PageNameExtender.set('mypagename');
GDL.ext.PageNameExtender.extend('sublevel1/sublevel2');

GDL.ext.PageNameExtender.reduce(1); // --> mypagename/sublevel1
GDL.ext.PageNameExtender.reduce(5); // --> mypagename
```

You can also use the flags `'ALL'` and `'LAST'`.

```javascript
GDL.ext.PageNameExtender.set('mypagename');
GDL.ext.PageNameExtender.extend('sublevel1/sublevel2/sublevel3');

GDL.ext.PageNameExtender.reduce('LAST'); // --> mypagename/sublevel1/sublevel2
GDL.ext.PageNameExtender.reduce('ALL'); // --> mypagename
```

By default, the `reduce` method keeps all the levels, that were added by `set`. You can use the second argument
`keepBasePageName` to manage this behaviour. The default is `true`.

```javascript
GDL.ext.PageNameExtender.set('mypagename/keeplevel');
GDL.ext.PageNameExtender.extend('sublevel1/sublevel2/sublevel3');

GDL.ext.PageNameExtender.reduce('LAST'); // --> mypagename/keeplevel/sublevel1/sublevel2
GDL.ext.PageNameExtender.reduce('ALL'); // --> mypagename/keeplevel
GDL.ext.PageNameExtender.reduce('ALL', false); // --> mypagename
GDL.ext.PageNameExtender.reduce(10); // --> mypagename/keeplevel
GDL.ext.PageNameExtender.reduce(10, false); // --> mypagename
```

### `prepend` and `append`

You can also get a temporary prefixed or postfixed version of the current page name. This could be helpful if you do
not want to work with permanent levels.

```javascript
GDL.ext.PageNameExtender.set('mypagename/sublevel1');

GDL.ext.PageNameExtender.prepend('PREFIX_'); // --> PREFIX_mypagename/sublevel1
// the next call to `get` will not contain the prefix anymore already.
GDL.ext.PageNameExtender.get(); // --> mypagename/sublevel1

GDL.ext.PageNameExtender.prepend('_POSTFIX'); // --> mypagename/sublevel1_POSTFIX
// the next call to `get` will not contain the postfix anymore already.
GDL.ext.PageNameExtender.get(); // --> mypagename/sublevel1
```
