# Extensions

Extensions are can help you to run some logic across the `GlobalDataLayer`, providing a way to track certain things without
the need to create the same logic over and over again.

## Contents

<!-- toc -->

- [registerExtension](#registerextension)
- [Creating an Extension](#creating-an-extension)
- [Loading an Extension](#loading-an-extension)
- [Calling an Extension Method](#calling-an-extension-method)
- [Available Extensions](#available-extensions)

<!-- tocstop -->

### registerExtension

Register an extension into the `GlobalDataLayer` instance by calling the `registerExtension` of the `GlobalDataLayer`.

| Param      | Description                                                                                      |
| ---------- | ------------------------------------------------------------------------------------------------ |
| ext        | `Object extends BaseExtension` It is the instance of an extension to register.                   |
| override   | `boolean` Register the extension and override it, also if it already exists. Default is `false`. |

```javascript
globalDataLayerLibraryInstance.registerExtension(new DefaultWebProperties(
  globalDataLayerLibraryInstance,
  {
    breakpoints: [480, 760, 1000, 1300, 1760, 1920],
    pageIdAlwaysUpToDate: false
  },
));
```

### Creating an Extension
Create your extension class inside the directory [`src/Extensions`](../../src/Extensions). Then extend your class with [`BaseExtension`](../../src/Extensions/BaseExtension/index.ts).

```javascript
export default class MyExtensionName extends Index {
  // ...
}
```

Inside the class you can create as many methods and logic as you want.

> If you want to know how to write your own extension, please also see the documentation of the
[`BaseExtension`](BaseExtension/README.md) class.

### Loading an Extension

As the extensions are not loaded automatically in the `GlobalDataLayer` class, you will need to register your extension to make it available later.

```javascript
globalDataLayerInstance.registerExtension(
  new MyExtensionName(globalDataLayerInstance, { "mySetting": "withValue" })
);
```

Note that the second parameter could contain any additional setting or information to set up your extension.

### Calling an Extension Method

After doing that you will be able to access the extension through the ext and the extensiom `name` property inside `GlobalDataLayer`. It would be like:

```javascript
 GDL.ext.MyExtensionName.register();
```

In this example we are accessing to the register method we created inside our extension, but you can create the methods you want.

### Available Extensions

- [`DefaultWebProperties`](DefaultWebProperties/README.md): To handle default properties, that could be used in every web application.
- [`PageNameExtender`](PageNameExtender/README.md): To handle the page name in single page applications or modules.
- [`ViewportTracker`](ViewportTracker/README.md): To track DOM elements come into view.














