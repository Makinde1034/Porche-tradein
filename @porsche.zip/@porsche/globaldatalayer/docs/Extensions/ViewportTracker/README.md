# Viewport Tracker

This GDL **extension** is meant to **track elements come into view**
Observes the visibility of registered DOM elements and tracks when entering/filling the viewport.
It can provide information of the position of these elements based on given Thresholds.
These thresholds are configurable in the settings object.

_Viewport tracker uses **Intersection Observer** to track elements visibility. If you need IE11 support please include 
the [polyfill](https://github.com/w3c/IntersectionObserver/tree/master/polyfill) in your site._

## Contents

<!-- toc -->

- [Tracking Conditions](#tracking-conditions)
- [Registration of the Extension](#registration-of-the-extension)
- [Register ViewportTracker Settings Object](#register-viewporttracker-settings-object)
- [Register element(s)](#register-elements)
  * [Type `RegisterElement`](#type-registerelement)
  * [Example](#example)
- [Unregister element(s)](#unregister-elements)
  * [Why is important to unregister](#why-is-important-to-unregister)
- [Pushed Event](#pushed-event)

<!-- tocstop -->

## Tracking Conditions

- The tracking event triggers everytime, when an element is shown in the user's viewport at a certain position.
  - when either
    - \>= **x%** of the element is **visible** in the user‘s viewport
    - \>= **x%** of the viewport is **filled** with the element
  - and the above applies for at least **1 second**
- The event will be tracked again under the same conditions as above, only after there was a point in time when the 
  conditions didn't apply.

The properties are configurable in the settings object.

## Registration of the Extension

Needs the current instance of the [`GlobalDataLayer`](../../GlobalDataLayer/README.md) that is used to push the tracking 
events when the given thresholds are met for an element. The settings object is optional.

```javascript
globalDataLayerInstance.registerExtension(
  new ViewportTracker(globalDataLayerInstance, {
    eventAction: 'PAGPCOM_GeneralEnterViewport_Load',
    minValidityPeriod: 1,
    thresholds: {
      visible: 0.3,
      filled: 0.5
    },
    onUpdate: (data: ElementStoreItem) => {
      // ...
    },
    checkTickFPS: 10
  })
);
```

## Register ViewportTracker Settings Object

| Setting              | Type and Description                                                                                                                                                                  |
| -------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `eventAction`        | `string` _(optional, default 'UNKNOWN')_ <br/>The event name that is used, when the event is pushed.                                                                                  |
| `minValidityPeriod`  | `number` _(optional, default 1)_ <br/>The minimum amount of seconds to pass with valid thresholds before a tracking event is pushed.                                                  |
| `thresholds`         | `object` _(optional)_ <br/>Thresholds that the element has to meet in order to be tracked.                                                                                            |
| `thresholds.visible` | `percentage` _(optional, default 0.3)_ <br/>How much of the element has to be visible on viewport. (min 0, max 1)                                                                     |
| `thresholds.filled`  | `percentage` _(optional, default 0.5)_ <br/>How much of the viewport is filled with the element. Useful for elements that are bigger than the viewport. (min 0, max 1)                |
| `checkTickFPS`       | `number` _(optional, default 10)_ <br/>How often in one second should the `ViewportTracker` check the visible elements. Keep this number lower than 10 to prevent performance issues. |

## Register element(s)

Register any DOM element for viewport tracking.

The `register` function wants an array of items to be observed. Even if it is only one item it should be wrapped into an 
array.

### Type `RegisterElement`

Is a type that has these properties.

| Property     | Type and Description                                                                                                                                  |
| ------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| `el`         | `DOM Element` The DOM element to be observed                                                                                                          |
| `id`         | `id` _(optional, default dom attribute id)_ <br/>Unique identifier for the element. Needed as `context.moduleId` for the event push to be meaningful. |
| `properties` | `pagDataItem` _(optional)_ <br/>Object containing any additional data to be appended to the event push.                                               |

### Example

Simple example to add one element with a custom id and custom properties to the observer.

```javascript
GDL.ext.ViewportTracker.register([
  {
    el: element,
    id: 'example-unique-id',
    properties: {
      collection: {
        myProperty: 'myValue'
      }
    }
  }
]);
```

## Unregister element(s)

Unregister a DOM element for viewport tracking The `unregister` function wants an array of items to be not observed anymore.

Us the same type [`RegisterElement`](#type-registerelement) as on the register. Although this time the _properties_ field is 
not taken into account.

### Why is important to unregister

When the element is not used anymore it should always be unregistered. This will make minimize the checks that the extension 
needs to do and therefore improves the overall performance.  
So everytime an element is not longer in use or destroyed, please call unregister method on the extension with the same 
element and id as it was registered once.

## Pushed Event

The basic pushed event will look like this. You can add more `properties` within the 
[`RegisterElement`](#type-registerelement) property `properties`.

```javascript
GDL.push('PAGPCOM_GeneralEnterViewport_Load', {
  context: {
    moduleId: 'myModuleId'
  },
  ...properties
});
```
