# GlobalDataLayer Library

## Contents

<!-- toc -->

- [Examples](#examples)
- [Constructor](#constructor)
  * [Constructor Arguments](#constructor-arguments)
- [Methods](#methods)
  * [push](#push)
  * [setDefaultProperties](#setdefaultproperties)
    + [Dynamic Values](#dynamic-values)
  * [getPagData](#getpagdata)
  * [registerExtension](#registerextension)

<!-- tocstop -->

## Examples

You can find an [`POC`](../../examples/POC/index.html) under [`/examples`](../../examples)
to see the [library] and some [Extensions](../Extensions/README.md) working.

## Constructor

Integrate the library into your code and instantiate by calling the constructor:

```javascript
import { GlobalDataLayer } from '@porsche/globaldatalayer';

const GDL = new GlobalDataLayer(mySettings);
```

### Constructor Arguments

```javascript
const GDL = new GlobalDataLayer({ eventMatrix: myEventsJson });
```

GDL accepts a settings object to modify certain default configuration. These are the properties that can be passed:

| Argument     | Param                                          | Description                                                                                                                                                                                                                                                                                                                                                         |
| ------------ | ---------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `settings`   | eventMatrix                                    | `Object` It is the object which will be use to perform the validations. This object is generated through the command `generate-event-matrix`. Read more about validation in [/docs/Utils/Validation](../Utils/Validation/README.md).                                                                                                                                |
|              | removeUnacceptableValues                       | `Object` Contain the custom configuration to remove automatically certain values of the objects passed.                                                                                                                                                                                                                                                             |
|              | removeUnacceptableValues.enabled               | `boolean` Enables the functionality. Default is `false`.                                                                                                                                                                                                                                                                                                            |
|              | removeUnacceptableValues.values                | `Array` Contains all the unacceptable values. Default is `['', undefined, null]`.                                                                                                                                                                                                                                                                                   |
|              | removeUnacceptableValues.executionPlace        | `enum ExecutionPlace` Should the properties removed before or after the merge with the `DefaultProperties`. This has different effects: `ExecutionPlace.AFTER_MERGE` can help to remove `DefaultProperties` from the final properties, while `ExecutionPlace.BEFORE_MERGE` will fallback to the given `DefaultProperties`. Default is `ExecutionPlace.AFTER_MERGE`. |
|              | allowUnknownPropsOnPush                        | `boolean` Allow to push properties that are not exist in the given `eventMatrix`. This can be overridden in the `options` of every `push`. Default is `false`.                                                                                                                                                                                                      |

## Methods

### push

Push data to the pagData global array by validating (optional) it against the given `eventMatrix`.

| Param                     | Description                                                                                                                                                              |
| ------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| event                     | `String` The event you want to push.                                                                                                                                     |
| eventData                 | `Object` Required properties for the event. _Please note that these data might be merged with the properties transferred already via the `setDefaultProperties` method._ |
| options                   | `Object` Set of options                                                                                                                                                  |
| options.turnOffValidation | `boolean` Turn off the validation of the given `eventData` against the given [`eventMatrix`](../Utils/Validation/README.md). Default is `false` when there is an active `eventMatrix`.                    |
| options.allowUnknownProps | `boolean` Allow to push properties that are not exist in the given `eventMatrix`. Default was set in the constructor or `false`.                                         |

> Learn more about validation in [/docs/Utils/Validation](../Utils/Validation/README.md).

### setDefaultProperties

Set default properties to one or multiple events to avoid repeating.

| Param             | Description                                                                   |
| ----------------- | ----------------------------------------------------------------------------- |
| event             | `String` The event name to bind the properties to.                            |
|                   | `String[]` Multiple event names to bind the properties to.                    |
|                   | `RegExp` A Regular Expression to match event names to bind the properties to. |
| defaultProperties | `Object` The default properties you want to set up.                           |

> Also see [`DefaultWebProperties`](../Extensions/DefaultWebProperties/README.md) extension.

#### Dynamic Values

You can also push **dynamic values**, a function that is always called at the moment some pushes an event.

```javascript
setDefaultProperties(
  'PAGPCOM_General_Pageload',
  {
    visitor: {
      deviceBrowserHeight: () => window.innerHeight.toString(),
    },
  }
);
```

### getPagData

Initialize the global array `pagaData`, if it is not already available, and return it. This method is for internal use, but
can also be helpful during debugging sessions.

### registerExtension

Register an extension into the GDL instance.

| Param      | Description                                                                                      |
| ---------- | ------------------------------------------------------------------------------------------------ |
| ext        | `Object extends BaseExtension` It is the instance of an extension to register.                   |
| override   | `boolean` Register the extension and override it, also if it already exists. Default is `false`. |

```javascript
GDL.registerExtension(new DefaultWebProperties(
  globalDataLayerLibraryInstance,
  {
    breakpoints: [480, 760, 1000, 1300, 1760, 1920],
    pageIdAlwaysUpToDate: false,
  },
));
```

> Learn more about Extensions in [`/docs/Extensions`](../Extensions/README.md).
