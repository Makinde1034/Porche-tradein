# Validation

The `GlobalDataLayer` will give you the option to validate event properties against a defined EventMatrix. The EventMatrix 
can be generated from the [DataLayer Excel] given by Smart Digital.

## Contents

<!-- toc -->

- [Event Matrix](#event-matrix)
  * [CLI](#cli)
  * [Porsche Data Layer Events Specification](#porsche-data-layer-events-specification)
  * [Structure](#structure)
- [Validation via Event Matrix](#validation-via-event-matrix)
- [Programmatically Disable Validation](#programmatically-disable-validation)
- [Validation Logging and Impact](#validation-logging-and-impact)
  * [Info: Success](#info-success)
  * [Warn: Failed](#warn-failed)
  * [Warn: Event not found](#warn-event-not-found)
  * [Warn: Mandatory property missing](#warn-mandatory-property-missing)
  * [Warn: Wrong property type](#warn-wrong-property-type)

<!-- tocstop -->

## Event Matrix

### CLI 

Do the converting in your project by using `@porsche/globaldatalayer-cli`. For more information see the readme file of the 
CLI package on [Porsche jFrog](https://porscheui.jfrog.io/ui/packages/npm:%2F%2F@porsche%2Fglobaldatalayer-cli/).

### Porsche Data Layer Events Specification

Use your projects preconverted _Event Matrix_ by using `@porsche/globaldatalayer-events`. For more information see the readme 
file of the package on [Porsche jFrog](https://porscheui.jfrog.io/ui/packages/npm:%2F%2F@porsche%2Fglobaldatalayer-events/).

### Structure

Find all available events in the `events` array (through that every event has an index):

```json
{
  "events": [
    "PAGPCOM_FindADealer_Pageload",
    "PAGPCOM_FindADealerSearch_Click",
    "PAGPCOM_FindADealerLocateMe_Click",
    "PAGPCOM_FindADealerSearchResults_Load"
  ]
}
```

Find all properties named by there full key as an object:

```json
{
  "visitor.deviceBrowserBreakpoint": {
    "t": "string",
    "e": {
      "0": 0,
      "1": 0
    },
    "r": 1
  }
}
```

All event properties have these three properties :

- `t`: The type of the property (`string`, `number`, `boolean`, ...).
- `e`: The events that can have this property. The numbers correspond with the index of an event inside the events array 
  (this concept keeps the file as light as possible). The value `0` is dummy value.
- `r`: The mandatory option. `1` property is mandatory property and therefore, it always has to be passed for all the
  events. `0` not mandatory.

## Validation via Event Matrix

The `eventMatrix` is a JSON, that allows the library to validate the events. Pass it to the constructor of 
the `GlobalDataLayer` as setting `eventMatrix`.

```javascript
const GDL = new GlobalDataLayer({ eventMatrix: myValidationData });
```

## Programmatically Disable Validation

The `GlobalDataLayer` method `push` has an option `turnOffValidation` to suppress the validation. 

```javascript
GDL.push('POCTEST_General_Pageload', myEventProperties, {turnOffValidation: true});
```

> Please use this functionality wisely. The validation feature should help you find errors. By bypassing it, you will not 
> see, if there are any errors you did not expect. Better you solve the problem in your code or by consulting Smart Digital 
> because of the [DataLayer Excel].

## Validation Logging and Impact

### Info: Success

If an event was validated successfully, there will be a console log and the event is pushed to the `pagData` array.

```
(i) Validation success for event 'POCTEST_General_Pageload'.
```

### Warn: Failed

If an event validation failed, there will be a console warning and the event is **NOT** pushed to the `pagData` array.

```
(!) Validation failed for event 'POCTEST_General_Pageload'. See logs above.
```

Also see the following events, that are logged during the validation process.

### Warn: Event not found

If an event name was not found in the events json, there will be a console warning and the event is **NOT** pushed to the 
`pagData` array.

```
(!) Event 'POCTEST_UnknownEvent' does not exist.
```

### Warn: Mandatory property missing

If an event property is defined as mandatory for the given event in the events json, there will be a console warning and 
the event is **NOT** pushed to the `pagData` array.

```
(!) context.applicationId: Property is missing.
```

### Warn: Wrong property type

If an event property is defined with a different type in the events json, there will be a console warning and 
the event is **NOT** pushed to the `pagData` array.

```
(!) context.applicationId: Wrong type detected. Expected 'string', got 'number'.
```

[Blog Post about CSV in Excel]: https://ashwaniashwin.wordpress.com/2013/04/19/save-excel-file-as-a-csv-semicolon-delimited-file-along-with-unicode-encoding/
[DataLayer Excel]: https://skyway.porsche.com/confluence/x/IJL9CQ
[PCOM Tracking Events Overview]: https://skyway.porsche.com/confluence/x/IJL9CQ













