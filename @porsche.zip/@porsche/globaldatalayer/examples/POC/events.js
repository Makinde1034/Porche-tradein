// eslint-disable-next-line @typescript-eslint/no-unused-vars
var GlobalDataLayerEventMatrix = {
    events: ['POCTEST_General_Pageload', 'POCTEST_GeneralEnterViewport_Load'],
    'componentClick.targetElement': {
        t: 'STRING',
        e: {
            '1': 0,
        },
        r: 0,
    },
    'context.applicationId': {
        t: 'STRING',
        e: {
            '0': 0,
            '1': 0,
        },
        r: 1,
    },
    'context.country': {
        t: 'STRING',
        e: {
            '0': 0,
            '1': 0,
        },
        r: 1,
    },
    'context.currency': {
        t: 'STRING',
        e: {
            '0': 0,
            '1': 0,
        },
        r: 0,
    },
    'context.eventAction': {
        t: 'STRING',
        e: {
            '0': 0,
            '1': 0,
        },
        r: 1,
    },
    'context.language': {
        t: 'STRING',
        e: {
            '0': 0,
            '1': 0,
        },
        r: 1,
    },
    'context.moduleId': {
        t: 'STRING',
        e: {
            '1': 0,
        },
        r: 1,
    },
    'context.organization': {
        t: 'STRING',
        e: {
            '0': 0,
            '1': 0,
        },
        r: 0,
    },
    'context.server': {
        t: 'STRING',
        e: {
            '0': 0,
            '1': 0,
        },
        r: 1,
    },
    'context.timestamp': {
        t: 'STRING',
        e: {
            '0': 0,
            '1': 0,
        },
        r: 1,
    },
    'pageExperience.pageCategory': {
        t: 'STRING',
        e: {
            '1': 0,
        },
        r: 0,
    },
    'pageExperience.pageId': {
        t: 'STRING',
        e: {
            '0': 0,
            '1': 0,
        },
        r: 0,
    },
    'pageExperience.pageName': {
        t: 'STRING',
        e: {
            '0': 0,
            '1': 0,
        },
        r: 1,
    },
    'visitor.deviceBrowserBreakpoint': {
        t: 'STRING',
        e: {
            '0': 0,
            '1': 0,
        },
        r: 1,
    },
    'visitor.deviceBrowserHeight': {
        t: 'STRING',
        e: {
            '0': 0,
            '1': 0,
        },
        r: 1,
    },
    'visitor.deviceBrowserOrientation': {
        t: 'STRING',
        e: {
            '0': 0,
            '1': 0,
        },
        r: 1,
    },
    'visitor.deviceBrowserWidth': {
        t: 'STRING',
        e: {
            '0': 0,
            '1': 0,
        },
        r: 1,
    },
    'visitor.deviceType': {
        t: 'STRING',
        e: {
            '0': 0,
            '1': 0,
        },
        r: 1,
    },
    'visitor.useragent': {
        t: 'STRING',
        e: {
            '0': 0,
            '1': 0,
        },
        r: 1,
    },
};
